#include <stdio.h>
#include <math.h>

#define PI 3.14159265358979323846
#define NUM_WHEELS 3

typedef struct {
    int can_id;
    int speedmode;
    int positionmode;
} MotorCommand;

typedef struct {
    double r;  // wheel radius or robot parameter
    double l;  // robot length/width parameter
} RobotParams;

void inverse_kinematics(double Vx, double Vy, double Wz, RobotParams* robot) {
    MotorCommand msgs[6];
    int i;
    
    // Initialize motor commands
    for (i = 0; i < 6; i++) {
        msgs[i].can_id = i + 1;
        if (i % 2 == 0) {
            msgs[i].speedmode = 1;  // True
            msgs[i].positionmode = 0;  // False
        } else {
            msgs[i].speedmode = 0;  // False
            msgs[i].positionmode = 1;  // True
        }
    }
    
    // Velocity components for each wheel
    double V_i_x[NUM_WHEELS] = {0.0, 0.0, 0.0};
    double V_i_y[NUM_WHEELS] = {0.0, 0.0, 0.0};
    
    double target_wheel_speed[NUM_WHEELS] = {0.0, 0.0, 0.0};
    double target_wheel_angle[NUM_WHEELS] = {0.0, 0.0, 0.0};
    double nearest_wheel_angle[NUM_WHEELS] = {0.0, 0.0, 0.0};
    
    // For the first wheel (index 0)
    V_i_x[0] = Vx;
    V_i_y[0] = Vy + Wz * robot->l;
    
    // For the second wheel (index 1)
    V_i_x[1] = Vx - Wz * robot->l * sin(PI / 3.0);
    V_i_y[1] = Vy - Wz * robot->l * sin(PI / 6.0);
    
    // For the third wheel (index 2)
    V_i_x[2] = Vx + Wz * robot->l * sin(PI / 3.0);
    V_i_y[2] = Vy - Wz * robot->l * sin(PI / 6.0);
    
    // Debug print
    printf("{Vx:.2f}, {Vy:.2f}, {Wz:.2f}\n", Vx, Vy, Wz);
    
    // Calculate wheel speeds and angles
    for (i = 0; i < NUM_WHEELS; i++) {
        target_wheel_speed[i] = sqrt(V_i_x[i] * V_i_x[i] + V_i_y[i] * V_i_y[i]) / robot->r;
        target_wheel_angle[i] = atan2(V_i_y[i], V_i_x[i]);
        
        // Wheel speed is absolute
        // Wheel angle is absolute
        // Print statements (commented in original)
        // printf("target_wheel_angle[%d]: %.2f, target_wheel_angle[%d]: %.2f\n", 
        //        i, target_wheel_angle[i], i, target_wheel_angle[i]);
    }
    
    // Output results
    printf("\nWheel Speeds and Angles:\n");
    for (i = 0; i < NUM_WHEELS; i++) {
        printf("Wheel %d: Speed = %.3f rad/s, Angle = %.3f rad (%.1f deg)\n", 
               i, 
               target_wheel_speed[i], 
               target_wheel_angle[i],
               target_wheel_angle[i] * 180.0 / PI);
    }
}

int main() {
    RobotParams robot;
    robot.r = 0.05;  // Example: 5cm wheel radius
    robot.l = 0.20;  // Example: 20cm robot dimension
    
    // Test case: move forward with some rotation
    double Vx = 0.0;   // 1 m/s forward
    double Vy = 0.0;   // 0.5 m/s sideways
    double Wz = 1;   // 0.2 rad/s rotation
    
    printf("Input velocities: Vx=%.2f m/s, Vy=%.2f m/s, Wz=%.2f rad/s\n\n", Vx, Vy, Wz);
    
    inverse_kinematics(Vx, Vy, Wz, &robot);
    
    return 0;
}