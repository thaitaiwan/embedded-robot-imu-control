import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Quaternion, TransformStamped
from std_msgs.msg import Int32
from tf2_ros import TransformBroadcaster
import math
import numpy as np


class ThreeEncoderDiffDriveNode(Node):
    """
    Differential Drive with 3 Encoders:
    - Left wheel encoder
    - Right wheel encoder  
    - Center/Auxiliary encoder (for better accuracy, perpendicular to drive wheels)
    
    Robot configuration (top view):
    
         Left ●────────● Right
         Wheel        Wheel
               |
               ● Center/Aux
               Encoder
    
    The center encoder helps correct for wheel slip and improves accuracy
    """
    
    def __init__(self):
        super().__init__('three_encoder_diff_drive_node')
        
        # ========== PARAMETERS ==========
        # Drive wheels (left and right)
        self.declare_parameter('wheel_base', 0.5)  # Distance between left and right wheels (m)
        self.declare_parameter('wheel_radius', 0.1)  # Radius of drive wheels (m)
        self.declare_parameter('encoder_resolution', 2048)  # Ticks per revolution
        
        # Auxiliary/Center encoder
        self.declare_parameter('aux_wheel_radius', 0.05)  # Auxiliary wheel radius (m)
        self.declare_parameter('aux_offset_x', 0.0)  # X offset from robot center (m)
        self.declare_parameter('aux_offset_y', 0.0)  # Y offset from robot center (m)
        self.declare_parameter('use_aux_encoder', True)  # Enable/disable auxiliary encoder
        
        # Publishing options
        self.declare_parameter('publish_tf', False)  # Let EKF handle TF
        self.declare_parameter('fusion_weight', 0.3)  # Weight for auxiliary encoder (0-1)
        
        # Get parameters
        self.wheel_base = self.get_parameter('wheel_base').value
        self.wheel_radius = self.get_parameter('wheel_radius').value
        self.encoder_resolution = self.get_parameter('encoder_resolution').value
        self.aux_wheel_radius = self.get_parameter('aux_wheel_radius').value
        self.aux_offset_x = self.get_parameter('aux_offset_x').value
        self.aux_offset_y = self.get_parameter('aux_offset_y').value
        self.use_aux_encoder = self.get_parameter('use_aux_encoder').value
        self.publish_tf = self.get_parameter('publish_tf').value
        self.fusion_weight = self.get_parameter('fusion_weight').value
        
        # ========== PUBLISHERS ==========
        self.odom_pub = self.create_publisher(Odometry, 'odom/encoder', 10)
        if self.publish_tf:
            self.tf_broadcaster = TransformBroadcaster(self)
        
        # ========== SUBSCRIBERS ==========
        # Subscribe to encoder topics - CHANGE THESE to match your hardware
        self.encoder_left_sub = self.create_subscription(
            Int32, 'encoder/left', self.encoder_left_callback, 10)
        self.encoder_right_sub = self.create_subscription(
            Int32, 'encoder/right', self.encoder_right_callback, 10)
        self.encoder_aux_sub = self.create_subscription(
            Int32, 'encoder/aux', self.encoder_aux_callback, 10)
        
        # ========== STATE VARIABLES ==========
        # Robot pose
        self.x = 0.0
        self.y = 0.0
        self.theta = 0.0
        
        # Encoder tick counts
        self.left_ticks = 0
        self.right_ticks = 0
        self.aux_ticks = 0
        
        # Previous encoder values
        self.last_left_ticks = 0
        self.last_right_ticks = 0
        self.last_aux_ticks = 0
        
        # Initialization flags
        self.left_initialized = False
        self.right_initialized = False
        self.aux_initialized = False
        
        # Timing
        self.last_time = self.get_clock().now()
        
        # Timer for odometry updates
        self.create_timer(0.02, self.update_odometry)  # 50 Hz
        
        self.get_logger().info('Three-Encoder Differential Drive Node Started')
        self.get_logger().info(f'Wheel base: {self.wheel_base}m')

        self.get_logger().info(f'Wheel radius: {self.wheel_radius}m')
        self.get_logger().info(f'Auxiliary encoder: {"ENABLED" if self.use_aux_encoder else "DISABLED"}')
        self.get_logger().info(f'Encoder resolution: {self.encoder_resolution} ticks/rev')
    
    def encoder_left_callback(self, msg):
        """Receive left wheel encoder ticks"""
        if not self.left_initialized:
            self.last_left_ticks = msg.data
            self.left_initialized = True
            self.get_logger().info('Left encoder initialized')
        self.left_ticks = msg.data
    
    def encoder_right_callback(self, msg):
        """Receive right wheel encoder ticks"""
        if not self.right_initialized:
            self.last_right_ticks = msg.data
            self.right_initialized = True
            self.get_logger().info('Right encoder initialized')
        self.right_ticks = msg.data
    
    def encoder_aux_callback(self, msg):
        """Receive auxiliary/center encoder ticks"""
        if not self.aux_initialized:
            self.last_aux_ticks = msg.data
            self.aux_initialized = True
            self.get_logger().info('Auxiliary encoder initialized')
        self.aux_ticks = msg.data
    
    def update_odometry(self):
        """
        Calculate odometry from three encoders
        Uses weighted fusion of drive wheels and auxiliary encoder
        """
        # Wait for all encoders to initialize
        if not self.left_initialized or not self.right_initialized:
            return
        
        if self.use_aux_encoder and not self.aux_initialized:
            return
        
        current_time = self.get_clock().now()
        dt = (current_time - self.last_time).nanoseconds / 1e9
        
        if dt <= 0:
            return
        
        # ========== CALCULATE FROM DRIVE WHEELS (LEFT + RIGHT) ==========
        # Change in encoder ticks
        delta_left_ticks = self.left_ticks - self.last_left_ticks
        delta_right_ticks = self.right_ticks - self.last_right_ticks
        
        # Convert ticks to distance (meters)
        meters_per_tick = (2.0 * math.pi * self.wheel_radius) / self.encoder_resolution
        
        delta_left = delta_left_ticks * meters_per_tick
        delta_right = delta_right_ticks * meters_per_tick
        
        # Calculate displacement and rotation from drive wheels
        delta_distance_drive = (delta_left + delta_right) / 2.0
        delta_theta_drive = (delta_right - delta_left) / self.wheel_base
        
        # ========== CALCULATE FROM AUXILIARY ENCODER ==========
        delta_distance_aux = 0.0
        
        if self.use_aux_encoder and self.aux_initialized:
            delta_aux_ticks = self.aux_ticks - self.last_aux_ticks
            
            # Convert auxiliary ticks to distance
            aux_meters_per_tick = (2.0 * math.pi * self.aux_wheel_radius) / self.encoder_resolution
            delta_distance_aux = delta_aux_ticks * aux_meters_per_tick
        
        # ========== FUSE MEASUREMENTS ==========
        # Weighted combination of drive wheels and auxiliary encoder
        if self.use_aux_encoder and self.aux_initialized:
            # Use weighted average
            delta_distance = (1.0 - self.fusion_weight) * delta_distance_drive + \
                           self.fusion_weight * delta_distance_aux
        else:
            # Use only drive wheels
            delta_distance = delta_distance_drive
        
        # Rotation comes from drive wheels only
        delta_theta = delta_theta_drive
        
        # ========== UPDATE ROBOT POSE ==========
        # Update heading first
        self.theta += delta_theta
        self.theta = self.normalize_angle(self.theta)
        
        # Update position (use average heading for curved paths)
        theta_avg = self.theta - delta_theta / 2.0
        delta_x = delta_distance * math.cos(theta_avg)
        delta_y = delta_distance * math.sin(theta_avg)
        
        self.x += delta_x
        self.y += delta_y
        
        # ========== CALCULATE VELOCITIES ==========

        v_x = delta_distance / dt
        v_y = 0.0  # Differential drive has no lateral movement
        omega = delta_theta / dt
        
        # ========== PUBLISH ODOMETRY MESSAGE ==========
        odom = Odometry()
        odom.header.stamp = current_time.to_msg()
        odom.header.frame_id = 'odom'
        odom.child_frame_id = 'base_link'
        
        # Position
        odom.pose.pose.position.x = self.x
        odom.pose.pose.position.y = self.y
        odom.pose.pose.position.z = 0.0
        
        # Orientation (quaternion from theta)
        quat = self.euler_to_quaternion(0.0, 0.0, self.theta)
        odom.pose.pose.orientation.x = quat[0]
        odom.pose.pose.orientation.y = quat[1]
        odom.pose.pose.orientation.z = quat[2]
        odom.pose.pose.orientation.w = quat[3]
        
        # Velocity
        odom.twist.twist.linear.x = v_x
        odom.twist.twist.linear.y = v_y
        odom.twist.twist.linear.z = 0.0
        odom.twist.twist.angular.x = 0.0
        odom.twist.twist.angular.y = 0.0
        odom.twist.twist.angular.z = omega
        
        # Covariance matrices
        # Lower values = more confident in measurements
        pose_covariance = [
            0.001, 0.0,   0.0, 0.0, 0.0, 0.0,    # x
            0.0,   0.001, 0.0, 0.0, 0.0, 0.0,    # y
            0.0,   0.0,   0.0, 0.0, 0.0, 0.0,    # z (not used)
            0.0,   0.0,   0.0, 0.0, 0.0, 0.0,    # roll (not used)
            0.0,   0.0,   0.0, 0.0, 0.0, 0.0,    # pitch (not used)
            0.0,   0.0,   0.0, 0.0, 0.0, 0.01    # yaw
        ]
        odom.pose.covariance = pose_covariance
        
        twist_covariance = [
            0.001, 0.0,   0.0, 0.0, 0.0, 0.0,    # v_x
            0.0,   0.001, 0.0, 0.0, 0.0, 0.0,    # v_y
            0.0,   0.0,   0.0, 0.0, 0.0, 0.0,    # v_z (not used)
            0.0,   0.0,   0.0, 0.0, 0.0, 0.0,    # omega_x (not used)
            0.0,   0.0,   0.0, 0.0, 0.0, 0.0,    # omega_y (not used)
            0.0,   0.0,   0.0, 0.0, 0.0, 0.01    # omega_z
        ]
        odom.twist.covariance = twist_covariance
        
        self.odom_pub.publish(odom)
        
        # Publish TF if enabled
        if self.publish_tf:
            self.broadcast_tf(odom)
        
        # Update last values
        self.last_left_ticks = self.left_ticks
        self.last_right_ticks = self.right_ticks
        self.last_aux_ticks = self.aux_ticks
        self.last_time = current_time
    
    def broadcast_tf(self, odom):
        """Broadcast transform from odom to base_link"""
        t = TransformStamped()
        t.header.stamp = odom.header.stamp
        t.header.frame_id = 'odom'
        t.child_frame_id = 'base_link'
        
        t.transform.translation.x = odom.pose.pose.position.x
        t.transform.translation.y = odom.pose.pose.position.y
        t.transform.translation.z = 0.0
        
        t.transform.rotation = odom.pose.pose.orientation
        
        self.tf_broadcaster.sendTransform(t)
    
    @staticmethod
    def normalize_angle(angle):
        """Normalize angle to [-pi, pi]"""
        while angle > math.pi:
            angle -= 2.0 * math.pi
        while angle < -math.pi:
            angle += 2.0 * math.pi
        return angle
    
    @staticmethod
    def euler_to_quaternion(roll, pitch, yaw):
        """Convert Euler angles to quaternion [x, y, z, w]"""
        cy = math.cos(yaw * 0.5)
        sy = math.sin(yaw * 0.5)
        cp = math.cos(pitch * 0.5)
        sp = math.sin(pitch * 0.5)
        cr = math.cos(roll * 0.5)
        sr = math.sin(roll * 0.5)
        
        qw = cr * cp * cy + sr * sp * sy
        qx = sr * cp * cy - cr * sp * sy
        qy = cr * sp * cy + sr * cp * sy
        qz = cr * cp * sy - sr * sp * cy
        
        return [qx, qy, qz, qw]


def main(args=None):
    rclpy.init(args=args)
    node = ThreeEncoderDiffDriveNode()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
