1. Install RPLidar ROS2 Package
sudo apt update
sudo apt install ros-<humble>-rplidar-ros
2. Setup Navigation2
sudo apt update
sudo apt install -y \
  ros-humble-navigation2 \
  ros-humble-nav2-bringup
3.Setup RPLidar ROS2 Humble
sudo chmod 777 /dev/ttyUSB0
cd src/rpldiar_ros-ros2/
source scripts/create_udev_rules.sh
4. Launch RPlidar
ros2 run rplidar_ros rplidar_a1
rviz2
5.topic list
/scan
6.Frequency and BW :

Frequency : 

average rate: 6.932
	min: 0.135s max: 0.148s std dev: 0.00524s window: 8
average rate: 6.940
	min: 0.135s max: 0.148s std dev: 0.00526s window: 15
average rate: 6.917
	min: 0.135s max: 0.148s std dev: 0.00494s window: 22
average rate: 6.925
	min: 0.134s max: 0.148s std dev: 0.00517s window: 29

BW : 

66.06 KB/s from 7 messages
	Message size mean: 8.70 KB min: 8.70 KB max: 8.70 KB
63.37 KB/s from 14 messages
	Message size mean: 8.70 KB min: 8.70 KB max: 8.70 KB
62.52 KB/s from 21 messages
	Message size mean: 8.70 KB min: 8.70 KB max: 8.70 KB
62.11 KB/s from 28 messages
	Message size mean: 8.70 KB min: 8.70 KB max: 8.70 KB


